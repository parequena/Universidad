#include <stdio.h>
#include <iostream>
#include <stdlib.h>
#include <cmath>
#include <time.h>

using namespace std;
 
void bechmark() {

    double a = 5.839283948594345, b = 0.999483743954345, c = 5.839283948594345;
    _asm 
    {
         
        fld a                       // Cargamos en fld(0) el valor de a
        fld b						// Cargamos en fld(1) el valor de b
		fld c						// Cargamos en fld(2) el valor de c
        mov ecx, 0                  // Contador inicializado a 0
         
bucle: 
        cmp ecx, 99999999			// Comprueba si el contador(ECX) ha llegado al valor requerido
        jnc fin                     // Salta a 'fin' si llega a n iteraciones
        fadd st(0), st(1)           // Suma el contenido de st(1) y de st(0) y se guarda en st(0)
		fadd st(0), st(2)           // Suma el contenido de st(2) y de st(0) y se guarda en st(0)
		fsub st(0), st(2)           // Resta al contenido de st(0) y el de st(2) y se guarda en st(0)
        fsub st(0), st(1)           // Resta al contenido de st(0) y el de st(1) y se guarda en st(0)
 
        fmul st(0), st(1)           // Multiplica el contenido de st(1) y el de st(0) y se guarda en st(0)
		fmul st(0), st(2)           // Multiplica el contenido de st(2) y el de st(0) y se guarda en st(0)
		fdiv st(0), st(2)           // Divide el contenido de st(0) entre el de st(2) y se guarda en st(0)
        fdiv st(0), st(1)           // Divide el contenido de st(0) entre el de st(1) y se guarda en st(0)
 
        fsqrt                       // Se hace la ra�z cuadrada del contenido en st(0) y se guarda en st(0)
        fmul st(0), st(0)           // Multiplica el contenido de st(0) por si mismo (como si lo elevaras a 2) y se guarda en st(0)
 
        inc ecx                     // Suma 1 al contador
        jmp  bucle

fin:
        fninit                      // Limpia el stack
    }
}
 
int main (void) 
{
    int x = 6;
    long double inicio, fin, ttotal = 0, media;
    for (int i = 0; i<x; i++)
    {
        inicio = clock();
        bechmark();   
        fin = clock();
        ttotal += fin - inicio;
    }
    media = (ttotal / x) / CLK_TCK;
	printf("The time was: %f\n", media); 
    getchar();
}