#include <iostream>
#include <fstream>
#include <stdlib.h>
#include <vector>
#include <time.h>

using namespace std;

void rellenaVectores(vector <int> &vectorX, vector <int> &vectorY)
{
	ifstream fich_entrada("entrada.txt");
	int valorX, valorY;

	if (fich_entrada.is_open())
	{
		do
		{
			fich_entrada >> valorX >> valorY;
			vectorX.push_back(valorX);
			vectorY.push_back(valorY);

		} while (!fich_entrada.eof());

		fich_entrada.close();
	}
	else
		cout << "El fichero: \"entrada.txt\" no se ha podido abrir.\n";
}

void mostrarDatos(vector <int> vectorX, vector <int> vectorY)
{
	cout << "X:\tY:\n";
	for (unsigned int i = 0; i < vectorX.size(); i++)
		cout << vectorX[i] << "\t" << vectorY[i] << endl;
	cout << "--------------------------------------\n";
}

int media(vector <int> vector)
{
	int acumulado = 0;
	for (unsigned int i = 0; i < vector.size(); i++)
		acumulado += vector[i];

	acumulado = acumulado / vector.size();

	return acumulado;
}

float mediaConjunta(vector <int> vectorX, vector <int> vectorY)
{
	float acumulado = 0;
	for (unsigned int i = 0; i < vectorX.size(); i++)
		acumulado += vectorX[i]*vectorY[i];

	acumulado = acumulado / vectorX.size();

	return acumulado;
}


int main(int argc, char *argv)
{
	
	vector <int> vectorX, vectorY;
	int mediaX=0, mediaY=0, mediaXY=0;
	float covarianza = 0, varianzaX = 0, varianzaY = 0, pendiente = 0, interseccion = 0;

	cout << "Empezamos a trabajar\n";
	int npuntos=60000;
	//rellenaVectores(vectorX, vectorY);
	int aux;
	 for(int j=0; j<npuntos; j++) {
		 aux = rand()%100;
		 vectorX.push_back(aux);
	}
	  for(int j=0; j<npuntos; j++) {
		   aux = rand()%100;
			vectorY.push_back(aux);
	}
	//mostrarDatos(vectorX, vectorY);
	long double inicio = clock();

	mediaX = media(vectorX);
	mediaY = media(vectorY);

	covarianza = mediaConjunta(vectorX, vectorY) - (mediaX * mediaY);
	varianzaX = mediaConjunta(vectorX, vectorX) - (mediaX * mediaX);
	varianzaY = mediaConjunta(vectorY, vectorY) - (mediaY * mediaY);

	pendiente = covarianza / mediaX;
	interseccion = (pendiente * -mediaX) + mediaY;

	cout << "Recta de regresion(y = mx + b):\n y = " << pendiente << "x ";
	if (interseccion < 0)
		cout << "- " << -interseccion;
	else
		cout << "+ " << interseccion;
	cout << endl;
	
	long double fin =(clock() - inicio)/ CLK_TCK;
	cout << "Tiempo dedicado: " << fin << endl;
	getchar();
}