#include <iostream>
#include <fstream>
#include <stdlib.h>
#include <vector>

using namespace std;

float npuntos = 0, mpendiente = 0, binterseccion = 0, sum_pro = 0, sum_y = 0, sum_x = 0, sum_x2 = 0;
vector <int> vectorX, vectorY;


// Modulo encargado en sumar el producto de los elementos de los dos vectores.
void sumaProductos()
{
	for (int i = 0; i < npuntos; i++)
		sum_pro += vectorX[i] + vectorY[i];
}

// Modulo encargado de sumar el cuadrado de los elementos del vector.
void sumaX2()
{
	for (int i = 0; i < npuntos; i++)
		sum_x2 += vectorX[i] * vectorX[i];
}

// Modulo encargado de sumar los elementos del vector X.
void sumaX()
{
	for (int i = 0; i < npuntos; i++)
		sum_x += vectorX[i];
}

// Modulo encargado de sumar los elementos del vector Y.
void sumaY()
{
	for (int i = 0; i < npuntos; i++)
		sum_y += vectorY[i];
}

// Modulo que calcula la pendiente de la recta.
void pendiente()
{
	mpendiente = (npuntos * sum_pro - sum_x * sum_y) / (npuntos * sum_x2 - sum_x * sum_x);
}

// Modulo que calcula la interseccion de la recta con el eje X.
void interseccion()
{
	binterseccion = (npuntos * sum_pro - sum_x * sum_y) / npuntos;
}

// Modulo que rellena los vectores desde un fichero de texto.
void rellenaVectores()
{
	ifstream fich_entrada("entrada.txt");
	int valorX, valorY;

	if (fich_entrada.is_open())
	{
		do
		{
			fich_entrada >> valorX >> valorY;
			vectorX.push_back(valorX);
			vectorY.push_back(valorY);
		} while (!fich_entrada.eof());

		fich_entrada.close();
	}
	else
		cout << "El fichero: \"entrada.txt\" no se ha podido abrir.\n";

	if (vectorX.size() == vectorY.size())
		npuntos = vectorX.size();
	/*else if (vectorX.size() < vectorY.size())
	vectorY.resize(vectorX.size());
	else
	vectorX.resize(vectorY.size());*/
}

// Moudlo que muestra los dos vecores
void mostrarDatos()
{
	cout << "X:\tY:\n";
	for (int i = 0; i < npuntos; i++)
		cout << vectorX[i] << "\t" << vectorY[i] << endl;
	cout << "--------------------------------------\n";
}

int main(int argc, char *argv)
{
	cout << "Empezamos a trabajar\n";
	rellenaVectores();
	mostrarDatos();
	sumaProductos();
	sumaY();
	sumaX();
	sumaX2();
	pendiente();
	interseccion();

	cout << "Recta de regresion(y = mx + b):\n y = " << mpendiente << "x + " << binterseccion << endl;
	getchar();
}