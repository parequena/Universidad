#include <iostream>
#include <time.h>
#include <fstream>
#include <stdio.h> 

using namespace std; 

void regresion(double* x, double* y, int npuntos);

int main()
{
	
	//N�mero de puntos
	int const npuntos = 25000;
  double x[npuntos],y[npuntos];

  for(int i=0; i<npuntos; i++) {
	  x[i]=rand();

  }
  /*x[0]=2;
  x[1]=3;
  x[2]=4;
  x[3]=4;
  x[4]=5;
  x[5]=6;
  x[6]=6;
  x[7]=7;
  x[8]=7;
  x[9]=8;
  x[10]=10;
  x[11]=10;*/

  /*y[0]=1;
  y[1]=3;
  y[2]=2;
  y[3]=4;
  y[4]=4;
  y[5]=4;
  y[6]=6;
  y[7]=4;
  y[8]=6;
  y[9]=7;
  y[10]=9;
  y[11]=10;
  //cout<<endl;*/

  for(int j=0; j<npuntos; j++) {
	  y[j]=rand();
  }
  long double inicio = clock();
  regresion(x, y, npuntos);
  long double fin =(clock() - inicio)/ CLK_TCK;
  cout << "Tiempo dedicado: " << fin << endl;
  getchar();
}
void regresion(double* x, double* y, int npuntos) {
	
  double m_x = 0, b_x = 0, m_y = 0, b_y = 0, negativo = -1;
  double numeros_double = (double) npuntos;
	_asm {
		mov eax, x					// Carga el vector x,
		mov ebx, y					// Carga el vector y 
		mov ecx, 8					// Carga el punto inicial
		mov edx, npuntos			// Cargamos el numero de puntos del problema
		imul edx, 8					// Multiplicamos el n�mero de puntos por el tama�o que ocupan en memoria
		movlpd xmm0, [eax]			// Carga en la parte baja de xmm0 el valor del primer x
		movhpd xmm0, [ebx]			// Carga en la parte alta de xmm0 el valor del primer y
		
bucle_1:
		cmp ecx, edx				// compara ecx(contador que va de 8 en 8) con edx(el valor total de todos nuestros registros) 
		jnc medias					// salta a medias cuando ecx y edx sean iguales

		movlpd xmm1, [eax+ecx]		//Carga un valor de x en la parte baja
		movhpd xmm1, [ebx+ecx]		//Carga un valor de y en la parte alta

		addpd xmm0, xmm1			// Suma un elemento(x,y) con el siguiente
		
		add ecx, 8					//Aumenta una posicion el contador(ecx)
		jmp bucle_1					//Salta al inicio del bucle_1

medias:	
		movlpd xmm1, numeros_double		// Carga en la parte baja de xmm1 el numero de puntos
		movhpd xmm1, numeros_double		// Carga en la parte alta de xmm1 el numero de puntos
		divpd xmm0, xmm1				// Divide la suma de todos los x e y(xmm0) por el tama�o(xmm1)

		mov ecx, 16					// Cargamos en ecx 16 que es el inicio de los valores

		movupd xmm2, [eax]			// Carga en xmm2 los 2 primeros valores de x
		movupd xmm3, [ebx]			// Carga en xmm3 los 2 primeros valores de y

		mulpd xmm2, xmm3			// Multiplica los 2 primeros valores de x con los dos primeros de y
		

bucle_2:
		cmp ecx, edx				//Compara ecx (contador) con edx (el valor total de todos nuestros registros) 
		jnc covarianza				// salta a medias cuando ecx y edx sean iguales

		movupd xmm3, [eax + ecx]	// Carga 2 puntos de x en xmm3
		movupd xmm4, [ebx + ecx]	//Carga 2 puntos de y en xmm4

		mulpd xmm3, xmm4			// Multiplica 2 valores de x con dos de y

		addpd xmm2, xmm3			//Suma acumulativa de las multiplicaciones

		add ecx, 16					//Aumenta el contador en 1 posicion
		jmp bucle_2					//Vuelve a repetir el bucle

covarianza:
		
		divpd xmm2, xmm1		//Divide la suma total de las multiplicaciones con el total de puntos
	
		movupd xmm3, xmm2		//Carga en xmm3 el contenido de xmm2
		shufpd xmm3, xmm3, 1	//Lo utilizamos para pasar a la parte baja el contenido de la parte alta
		addsd xmm2, xmm3		//Suma la parte baja de xmm2 con la de xmm3 y las almacena en xmm2(sin distinci�n de partes)

		movupd xmm3, xmm0		//Se almacena el contenido de xmm0 en xmm3
		shufpd xmm3, xmm3, 1	//Lo utilizamos para pasar a la parte baja el contenido de la parte alta
		mulsd xmm3, xmm0		//Multiplica la parte baja de xmm3 con la de xmm0 y se guarda en xmm3 (multiplica las medias de x e y)
  
		subsd xmm2, xmm3		//Resta la parte baja de xmm2 por la de xmm3 y las almacena en xmm2 (aqu� tenemos la covarianza)
		

		mov ecx, 8				//Movemos a ecx el valor de 8 (esto es el contador)
		
		movlpd xmm3, [eax]		//Mueve a la parte baja de xmm3 el primer valor del array eax
		movhpd xmm3, [ebx]		//Mueve a la parte alta de xmm3 el primer valor del array ebx
		movupd xmm4, xmm3		//Carga en xmm4 los valores de xmm3
		mulpd xmm3, xmm4		//Multiplica cada parte de xmm3 con las de xmm4
		

bucle_3:
		cmp ecx, edx			//Compara ecx (contador) con edx (el valor total de todos nuestros registros) 
		jnc varianzas			//Salta a varianzas cuando ecx y edx sean iguales
		movlpd xmm4, [eax+ecx]  //Carga en la parte baja de xmm4 el siguiente valor del array eax
		movhpd xmm4, [ebx+ecx]  //Carga en la parte alta de xmm4 el siguiente valor del array ebx
		movupd xmm5, xmm4		//Carga en xmm5 los valores de xmm4

		mulpd xmm4, xmm5		//Multiplica cada parte de xmm4 con las de xmm5
		
		addpd xmm3, xmm4		//Suma acumulativa de los cuadrados

		add ecx, 8				//Mueve el iterador al siguiente valor
		jmp bucle_3				//Salta a bucle_3

varianzas:

		divpd xmm3, xmm1		//Se divide las sumas de los cuadrados de x e y entre el n�mero de puntos
		
		movupd xmm4, xmm0		//Se almacena en xmm4 el valor de xmm0 (medias aritm�ticas)
		mulpd xmm4, xmm0		//Se elevan al cuadrado las medias

		subpd xmm3, xmm4		//Se resta a las varianzas los cuadrados de las medias
								

recta:

								//Tenemos: medias (xmm0), numero puntos(xmm1) 
								//covarianza (xmm2 low) y varianzas (xmm3)
		movupd xmm4, xmm2		
		divsd xmm4, xmm3		//Se divide la covarianza entre la varianza de x
		movlpd m_x, xmm4		//Mueve el contenido de xmm4 a m_x

		movupd xmm5, xmm0		//Carga en xmm5 las medias
		movlpd xmm6, negativo	//Carga a la parte baja de xmm6 el valor -1
		movhpd xmm6, negativo	//Carga a la parte alta de xmm6 el valor -1
		mulpd xmm5, xmm6		//Cambia el signo de los valores de xmm5
		
		
		shufpd xmm0, xmm0, 1	
		
		mulsd xmm4, xmm5		//Multiplica la parte baja de xmm4 con la de xmm5
		movlpd [ebx], xmm4		//Mueve a la parte baja del primer valor de ebx el valor de la parte baja de xmm4
		movlpd [ebx+16], xmm0	//Mueve a la parte baja del segundo valor de ebx el valor de la parte baja de xmm0
		addsd xmm4, xmm0		//Suma la parte baja de xmm4 y la parte baja de xmm0
		movlpd b_x, xmm4		//Mueve la parte baja de xmm4 a b_x
		
 		movupd xmm4, xmm2		//Carga el contenido de xmm2 a xmm4
		shufpd xmm3, xmm3, 1	
		divsd xmm4, xmm3		//Divide la parte baja de xmm4 por la de xmm3
		movlpd m_y, xmm4		//Carga la parte baja de xmm4 a m_y

		shufpd xmm5, xmm5, 1
		mulsd xmm4, xmm5		//Se multiplica la parte baja de xmm5 con la de xmm4
		shufpd xmm0, xmm0, 1
		addsd xmm4, xmm0		//Suma la parte baja de xmm4 con la de xmm0
		movlpd b_y, xmm4		//Carga a b_y la parte baja de xmm4
		




	}

	cout<<m_x<<"x  "<<b_x<<endl;
	cout<<m_y<<"y  "<<b_y<<endl;
  }